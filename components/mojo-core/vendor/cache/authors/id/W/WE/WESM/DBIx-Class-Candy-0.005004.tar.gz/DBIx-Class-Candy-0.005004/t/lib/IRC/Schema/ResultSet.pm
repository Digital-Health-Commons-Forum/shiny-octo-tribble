package IRC::Schema::ResultSet;

use strict;
use warnings;

use base 'DBIx::Class::ResultSet';

1;
