package IRC::Schema::ResultSet::User;

use DBIx::Class::Candy::ResultSet
   -base => 'IRC::Schema::ResultSet';

1;
