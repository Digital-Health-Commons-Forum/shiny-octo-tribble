package PerlIO::utf8_strict;

0;    # make require fail
