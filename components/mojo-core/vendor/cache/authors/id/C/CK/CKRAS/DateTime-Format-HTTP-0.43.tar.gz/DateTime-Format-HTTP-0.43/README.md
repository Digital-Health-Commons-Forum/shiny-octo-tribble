# DateTime-Format-HTTP
Date conversion routines for Perl 5

[![CI](https://github.com/Htbaa/DateTime-Format-HTTP/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/Htbaa/DateTime-Format-HTTP/actions/workflows/ci.yml)
