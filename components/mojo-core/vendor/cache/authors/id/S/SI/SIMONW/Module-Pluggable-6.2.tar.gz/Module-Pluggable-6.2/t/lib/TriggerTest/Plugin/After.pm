package TriggerTest::Plugin::After;

1;