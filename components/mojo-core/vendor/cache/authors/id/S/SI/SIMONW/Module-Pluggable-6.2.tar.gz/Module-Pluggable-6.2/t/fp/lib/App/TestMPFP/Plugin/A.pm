package App::TestMPFP::Plugin::A;
1;
