package Apple::Double::File;
1;
