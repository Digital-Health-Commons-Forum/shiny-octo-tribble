package Acme::FooBar;

our $quux = "hello";

1;

